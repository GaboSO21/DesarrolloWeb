package com.techshop.techshop.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.techshop.techshop.Model.*;

public interface CreditoRepository extends JpaRepository<Credito, Integer> {

}
