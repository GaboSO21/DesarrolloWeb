package com.techshop.techshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TechshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(TechshopApplication.class, args);
	}

}
